
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'rockinliam',
  applicationName: 'news-ai',
  appUid: 'nCGJ2Vl9hk8qnYtcw2',
  orgUid: 'LP1ktJ0FjSnF0SPvcQ',
  deploymentUid: '9d91836f-1485-4ca9-bbb8-7520292febee',
  serviceName: 'news-server',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'develop',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.8.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'news-server-develop-getHeadlines', timeout: 10 };

try {
  const userHandler = require('./src/lambdas/getHeadlines.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}