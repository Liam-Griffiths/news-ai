
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'rockinliam',
  applicationName: 'news-ai',
  appUid: 'nCGJ2Vl9hk8qnYtcw2',
  orgUid: 'LP1ktJ0FjSnF0SPvcQ',
  deploymentUid: '45573489-7f44-4683-b15b-310c4e95d879',
  serviceName: 'news-server',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'develop',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.8.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'news-server-develop-buildHeadlines', timeout: 900 };

try {
  const userHandler = require('./src/lambdas/buildHeadlines.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}